<?php
function get_email_ids()
{
global $wpdb;
$servername = $wpdb->dbhost;
$username = $wpdb->dbuser;
$password = $wpdb->dbpassword;
$dbname = $wpdb->dbname;
$prefix= $wpdb->prefix;
// Create connection
error_reporting(0);
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$table_name=$prefix."comments";
$sql = "SELECT comment_author_email FROM $table_name";
$result = $conn->query($sql);
echo <<<END

END;
if ($result->num_rows > 0) {
    // output data of each row
    echo "<h3>Total email id = ".(mysqli_num_rows($result)-1)."</h3>";
    while($row = $result->fetch_assoc()) {
        if(strcmp("wapuu@wordpress.example",$row["comment_author_email"])!=0)
          echo  $row["comment_author_email"]."<br>";
    }
} else {
    echo "0 results";
}

$conn->close();
}
?>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="main.css">
    <style>
    .container
    {
      margin:1%;
      padding:1%;
      max-width:95%;
      font-size: 1.2em;
    }
    .container p
    {
      font-size: 1em;

    }
    .email-holder
    {
      color:#4691f6;
      padding-left: 10px;
line-height:1.5;
    }
    </style>
  </head>
  <div class="container">
    <h1>Email List</h1>
    <div>
      <p>Get the email ids of all those who comment in your page. You heve the email Ids so now you can add them to your subscriber list or do anything with them.Have Fun!!</p>
    </div>
    <div class="email-holder">
      <?php echo get_email_ids()?>
    </div>
  </div>
</html>
