<?php
  /**
  *Plugin Name:Email Id From Comments
  *Plugin URI:http://the-tinker-project.co.in/project/wp-plugin/email-id-from-comments/
  *Author: Bisvarup Mukherjee
  *Author URI:http://bisho.the-tinker-project.co.in/
  *Version: 1.0
  *Lisence:GPLv2
  *Description: This plugin gets all the emails ids which belong to the people who commented on your site.
  */

add_action('admin_menu','my_admin_menu');
function my_admin_menu()
{
  add_menu_page('Email List','Email List','manage_options','footer_setting_page','bm_footer_text','dashicons-email',2);
}
function bm_footer_text()
{
  require("main.php");
}

?>
