<?php
  /**
  *Plugin Name:Basic plugin
  *Plugin URI:http://link.com
  *Author: Bisvarup Mukherjee
  *Author URI:http://link.com
  *Version: 1.0
  *Lisence:GPLv2
  *Description: loreum ipsum
  */

add_action('admin_menu','my_admin_menu');
function my_admin_menu()
{
  add_menu_page('Email List','Email List','manage_options','footer_setting_page','bm_footer_text','dashicons-email',2);
}
function bm_footer_text()
{
  require("main.php");
}

?>
